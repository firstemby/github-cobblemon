"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stadium_policy_exports = {};
__export(stadium_policy_exports, {
  STADIUM_MECHANICS: () => STADIUM_MECHANICS,
  allowsStadiumMechanic: () => allowsStadiumMechanic,
  getStadiumPolicy: () => getStadiumPolicy,
  setStadiumPolicy: () => setStadiumPolicy
});
module.exports = __toCommonJS(stadium_policy_exports);
const STADIUM_MECHANICS = ["mega_evolution", "z_moves", "dynamax", "terastallization"];
const policies = /* @__PURE__ */ new WeakMap();
function setStadiumPolicy(battle, policy) {
  policies.set(battle, policy);
}
function getStadiumPolicy(battle) {
  return policies.get(battle);
}
function allowsStadiumMechanic(battle, mechanic) {
  return policies.get(battle)?.mechanics?.has(mechanic) ?? true;
}
//# sourceMappingURL=stadium-policy.js.map
