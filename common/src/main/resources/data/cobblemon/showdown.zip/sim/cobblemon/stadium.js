"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var stadium_exports = {};
__export(stadium_exports, {
  getStadiumCapabilities: () => getStadiumCapabilities,
  resolveStadiumTimeout: () => resolveStadiumTimeout,
  sendStadiumChoice: () => sendStadiumChoice,
  startStadiumBattle: () => startStadiumBattle,
  validateStadiumBattle: () => validateStadiumBattle
});
module.exports = __toCommonJS(stadium_exports);
var import_battle_stream = require("../battle-stream");
var import_dex = require("../dex");
var import_teams = require("../teams");
var import_stadium_policy = require("./stadium-policy");
function record(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}
function result(errors) {
  return { protocolVersion: 1, ok: !errors.length, errors };
}
function getStadiumCapabilities() {
  return {
    protocolVersion: 1,
    features: ["team-validation", "structured-startup", "team-preview", "mechanic-restrictions", "timeout-resolution"],
    gameTypes: ["singles", "doubles"],
    clauses: ["species_clause"],
    levelPolicies: ["reject"],
    mechanics: [...import_stadium_policy.STADIUM_MECHANICS]
  };
}
function inspectRequest(json) {
  const errors = [];
  const error = (code, field, message, context = {}) => {
    errors.push({ code, field, message, ...context });
  };
  let request;
  try {
    if (typeof json !== "string" || json.length > 131072)
      throw new Error();
    request = JSON.parse(json);
  } catch {
    error("malformed_request", "request", "Expected a JSON request of at most 131072 characters.");
    return { result: result(errors) };
  }
  if (!record(request)) {
    error("malformed_request", "request", "Expected a JSON object.");
    return { result: result(errors) };
  }
  if (request.protocolVersion !== 1)
    error("unsupported_protocol", "protocolVersion", "Protocol version 1 is required.");
  for (const key of Object.keys(request)) {
    if (!["protocolVersion", "format", "sides"].includes(key))
      error("unsupported_field", key, "Unknown request field.");
  }
  const format = request.format;
  if (!record(format)) {
    error("malformed_format", "format", "Expected a format object.");
    return { result: result(errors) };
  }
  const formatFields = [
    "id",
    "gameType",
    "maxPartySize",
    "maxLevel",
    "levelPolicy",
    "teamPreview",
    "clauses",
    "allowHeldItems",
    "uniqueHeldItems",
    "bans",
    "allowedMechanics"
  ];
  for (const key of Object.keys(format)) {
    if (!formatFields.includes(key))
      error("unsupported_rule", `format.${key}`, "This format setting is not supported.");
  }
  if (format.id !== void 0 && (typeof format.id !== "string" || format.id.length > 80)) {
    error("malformed_format", "format.id", "Format ID must be at most 80 characters.");
  }
  if (!["singles", "doubles"].includes(format.gameType))
    error("unsupported_game_type", "format.gameType", "Use singles or doubles.");
  const active = format.gameType === "doubles" ? 2 : 1;
  const limit = format.maxPartySize === void 0 ? 6 : format.maxPartySize;
  if (!Number.isInteger(limit) || limit < active || limit > 6)
    error("malformed_format", "format.maxPartySize", "Invalid party size.");
  const maxLevel = format.maxLevel === void 0 ? 0 : format.maxLevel;
  if (!Number.isInteger(maxLevel) || maxLevel < 0 || maxLevel > 100)
    error("malformed_format", "format.maxLevel", "Use 0 through 100; 0 means no ceiling.");
  if (format.levelPolicy !== void 0 && format.levelPolicy !== "reject")
    error("unsupported_rule", "format.levelPolicy", "Only rejection is supported.");
  if (format.teamPreview !== void 0 && typeof format.teamPreview !== "boolean") {
    error("malformed_format", "format.teamPreview", "Expected a boolean.");
  }
  if (format.allowedMechanics !== void 0 && (!Array.isArray(format.allowedMechanics) || format.allowedMechanics.length > import_stadium_policy.STADIUM_MECHANICS.length || format.allowedMechanics.some((mechanic) => !import_stadium_policy.STADIUM_MECHANICS.includes(mechanic)))) {
    error("unsupported_rule", "format.allowedMechanics", "Unknown mechanic restrictions.");
  }
  for (const key of ["allowHeldItems", "uniqueHeldItems"]) {
    if (format[key] !== void 0 && typeof format[key] !== "boolean")
      error("malformed_format", `format.${key}`, "Expected a boolean.");
  }
  const clauses = format.clauses === void 0 ? [] : format.clauses;
  if (!Array.isArray(clauses) || clauses.length > 16) {
    error("malformed_format", "format.clauses", "Expected a clause list.");
  } else {
    for (const clause of clauses) {
      if (clause !== "species_clause")
        error("unsupported_rule", "format.clauses", "Unsupported clause.");
    }
  }
  const dex = import_dex.Dex.mod("cobblemon");
  const tables = { pokemon: dex.species, moves: dex.moves, abilities: dex.abilities, items: dex.items };
  const bans = {};
  if (format.bans !== void 0 && !record(format.bans))
    error("malformed_format", "format.bans", "Expected ban lists.");
  for (const key of Object.keys(format.bans ?? {})) {
    if (!Object.prototype.hasOwnProperty.call(tables, key)) {
      error("unsupported_rule", `format.bans.${key}`, "Unknown ban category.");
    }
  }
  for (const [category, table] of Object.entries(tables)) {
    bans[category] = /* @__PURE__ */ new Set();
    const values = format.bans?.[category] ?? [];
    if (!Array.isArray(values) || values.length > 256) {
      error("malformed_format", `format.bans.${category}`, "Expected at most 256 canonical IDs.");
      continue;
    }
    for (const id of values) {
      if (typeof id !== "string" || !/^[a-z0-9]{1,80}$/.test(id)) {
        error("malformed_format", `format.bans.${category}`, "Use canonical Showdown IDs.");
      } else if (!table.get(id).exists) {
        error("unknown_id", `format.bans.${category}`, "This ID is not registered.", { value: id });
      } else {
        bans[category].add(table.get(id).id);
      }
    }
  }
  if (!Array.isArray(request.sides) || request.sides.length !== 2) {
    error("malformed_sides", "sides", "Exactly p1 and p2 are required.");
    return { result: result(errors) };
  }
  const sides = /* @__PURE__ */ new Set();
  const uuids = /* @__PURE__ */ new Set();
  for (const side of request.sides) {
    if (!record(side) || !["p1", "p2"].includes(side.id) || sides.has(side.id)) {
      error("malformed_side", "sides", "Exactly one p1 and one p2 are required.");
      continue;
    }
    sides.add(side.id);
    for (const key of Object.keys(side)) {
      if (!["id", "name", "team"].includes(key))
        error("unsupported_field", `sides.${key}`, "Unknown side field.", { side: side.id });
    }
    if (side.name !== void 0 && (typeof side.name !== "string" || side.name.length > 80 || /[\r\n|]/.test(side.name))) {
      error("malformed_side", "name", "Invalid side name.", { side: side.id });
    }
    if (typeof side.team !== "string" || !side.team || side.team.length > 49152 || /[\r\n]/.test(side.team)) {
      error("malformed_team", "team", "Expected a Cobblemon packed party.", { side: side.id });
      continue;
    }
    const packed = side.team.split("]");
    if (packed.length < active || packed.length > limit || packed.length > 6) {
      error("party_size", "team", "Party size is outside this format's bounds.", { side: side.id });
    }
    if (packed.length > 6)
      continue;
    const speciesSeen = /* @__PURE__ */ new Set();
    const itemsSeen = /* @__PURE__ */ new Set();
    let healthy = 0;
    for (const [index, member] of packed.entries()) {
      const fields = member.split("|");
      const context = { side: side.id, pokemonUuid: fields[2]?.slice(0, 36) };
      const integer = (value, minimum, maximum) => /^\d+$/.test(value) && Number(value) >= minimum && Number(value) <= maximum;
      if (fields.length !== 17 || !/^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(fields[2])) {
        error("malformed_team", "team", "Invalid Cobblemon packed member or UUID.", { side: side.id });
        continue;
      }
      const uuid = fields[2].toLowerCase();
      if (uuids.has(uuid))
        error("duplicate_uuid", "uuid", "A Pok\xE9mon cannot occupy multiple party slots.", context);
      uuids.add(uuid);
      if (!integer(fields[3], 0, 1e6) || fields[5] !== "-1" && !integer(fields[5], 0, 1e6) || !integer(fields[15] || "100", 1, 9999)) {
        error("malformed_team", "team", "Invalid HP, status duration or level.", context);
        continue;
      }
      const validStats = (value, maximum) => !value || value.split(",").length === 6 && value.split(",").every((stat) => !stat || integer(stat, 0, maximum));
      if (!validStats(fields[11], 252) || !validStats(fields[13], 31) || !["", "M", "F", "N"].includes(fields[12]) || !["", "S"].includes(fields[14])) {
        error("malformed_team", "team", "Invalid stats, gender or shiny marker.", context);
      }
      if (fields[4] && !dex.conditions.get(fields[4]).exists)
        error("unknown_id", "status", "This status is not registered.", context);
      if (!dex.natures.get(fields[10]).exists)
        error("unknown_id", "nature", "This nature is not registered.", context);
      const misc = fields[16].split(",");
      for (const [field, value] of [["hpType", misc[2]], ["teraType", misc[5]]]) {
        if (value && (!dex.types.get(value).exists || dex.types.get(value).name !== value)) {
          error("unknown_id", field, "Use a registered type name.", context);
        }
      }
      if (Number(fields[3]) > 0)
        healthy++;
      if (!format.teamPreview && index < active && Number(fields[3]) === 0) {
        error("fainted_starter", "currentHealth", "Initial active slots must be healthy.", context);
      }
      const moveIds = fields[8].split(",");
      const pp = fields[9].split(",");
      if (moveIds.length > 4 || pp.length !== moveIds.length || pp.some((value) => {
        const pair = value.split("/");
        return pair.length !== 2 || !integer(pair[0], 0, 1e6) || !integer(pair[1], 1, 1e6) || Number(pair[0]) > Number(pair[1]);
      })) {
        error("malformed_team", "movesInfo", "Invalid move slots or PP data.", context);
        continue;
      }
      const set = import_teams.Teams.unpack(member)?.[0];
      if (!set) {
        error("malformed_team", "team", "Could not unpack the party member.", context);
        continue;
      }
      const species = dex.species.get(set.species);
      const base = (0, import_dex.toID)(species.baseSpecies);
      const ids = {
        pokemon: [(0, import_dex.toID)(set.species)],
        moves: set.moves.map(import_dex.toID),
        abilities: [(0, import_dex.toID)(set.ability)],
        items: set.item ? [(0, import_dex.toID)(set.item)] : []
      };
      for (const [category, values] of Object.entries(ids)) {
        const table = tables[category];
        for (const id of values) {
          if (!table.get(id).exists)
            error("unknown_id", category, "This ID is not registered.", { ...context, value: id });
          if (bans[category].has(id) || category === "pokemon" && bans.pokemon.has(base)) {
            error(`banned_${category === "pokemon" ? "pokemon" : category === "abilities" ? "ability" : category.slice(0, -1)}`, category, "This entry is banned.", { ...context, value: id });
          }
        }
      }
      if (Array.isArray(clauses) && clauses.includes("species_clause") && speciesSeen.has(base))
        error("species_clause", "pokemon", "Duplicate base species.", context);
      speciesSeen.add(base);
      if (maxLevel && (set.level ?? 100) > maxLevel)
        error("maximum_level", "level", "Level exceeds this format's ceiling.", context);
      const item = (0, import_dex.toID)(set.item);
      if (item && format.allowHeldItems === false)
        error("held_items_disabled", "items", "Held battle items are disabled.", context);
      if (item && format.uniqueHeldItems && itemsSeen.has(item))
        error("unique_held_items", "items", "Duplicate held battle item.", context);
      itemsSeen.add(item);
    }
    if (format.teamPreview && healthy < active) {
      error("insufficient_healthy", "currentHealth", "Not enough healthy Pok\xE9mon to fill the active slots.", { side: side.id });
    }
  }
  return { request, result: result(errors) };
}
function validateStadiumBattle(requestJson) {
  try {
    return inspectRequest(requestJson).result;
  } catch {
    return result([{ code: "validation_failed", field: "request", message: "Engine validation failed." }]);
  }
}
class StadiumBattleStream extends import_battle_stream.BattleStream {
  constructor() {
    super(...arguments);
    this.accepted = false;
    this.onFailure = () => {
    };
  }
  fail() {
    this.push("stadiumerror\n" + JSON.stringify(result([
      { code: "battle_failed", field: "battle", message: "The engine battle stream failed." }
    ])));
    this.onFailure();
    this._writeEnd();
  }
  _write(chunk) {
    try {
      super._write(chunk);
    } catch (error) {
      if (!this.accepted)
        throw error;
      this.fail();
    }
  }
}
function stadiumOperation(battles, battleId, requestJson, operation) {
  const stream = battles.get(battleId);
  if (!(stream instanceof StadiumBattleStream) || !stream.battle || stream.battle.ended) {
    return result([{ code: "battle_unavailable", field: "battleId", message: "No active stadium battle." }]);
  }
  let request;
  try {
    if (typeof requestJson !== "string" || requestJson.length > 4096)
      throw new Error();
    request = JSON.parse(requestJson);
    if (!record(request))
      throw new Error();
  } catch {
    return result([{ code: "malformed_request", field: "request", message: "Expected a bounded JSON object." }]);
  }
  if (request.protocolVersion !== 1) {
    return result([{ code: "unsupported_protocol", field: "protocolVersion", message: "Protocol version 1 is required." }]);
  }
  try {
    return operation(stream, request);
  } catch {
    stream.fail();
    return result([{ code: "battle_failed", field: "battle", message: "The engine battle stream failed." }]);
  }
}
function sendStadiumChoice(battles, battleId, requestJson) {
  return stadiumOperation(battles, battleId, requestJson, (stream, request) => {
    const battle = stream.battle;
    if (!["p1", "p2"].includes(request.side) || !Number.isSafeInteger(request.rqid) || typeof request.choice !== "string" || /[\r\n]/.test(request.choice) || Object.keys(request).some((key) => !["protocolVersion", "side", "rqid", "choice"].includes(key))) {
      return result([{ code: "malformed_choice", field: "choice", message: "Invalid stadium choice." }]);
    }
    const side = battle.getSide(request.side);
    if (!side.requestState || side.activeRequest?.rqid !== request.rqid || side.isChoiceDone()) {
      return result([{ code: "stale_choice", field: "rqid", side: side.id, message: "This request is no longer awaiting a choice." }]);
    }
    if (side.requestState === "teampreview" && !/^team [1-6](?:,[1-6]){0,5}$/.test(request.choice)) {
      return result([{ code: "invalid_choice", field: "choice", side: side.id, message: "Submit the full party order." }]);
    }
    const accepted = battle.choose(side.id, request.choice);
    if (!accepted)
      side.clearChoice();
    battle.sendUpdates();
    return accepted ? result([]) : result([
      { code: "invalid_choice", field: "choice", side: side.id, message: "The engine rejected this choice." }
    ]);
  });
}
function resolveStadiumTimeout(battles, battleId, requestJson) {
  return stadiumOperation(battles, battleId, requestJson, (stream, request) => {
    const battle = stream.battle;
    if (!["decision", "match"].includes(request.scope) || Object.keys(request).some((key) => !["protocolVersion", "scope", "expiredSides"].includes(key))) {
      return result([{ code: "malformed_timeout", field: "scope", message: "Invalid timeout scope." }]);
    }
    let winner = null;
    if (request.scope === "decision") {
      const expired = request.expiredSides;
      if (!Array.isArray(expired) || !expired.length || expired.length > 2 || expired.some((entry) => !record(entry) || !["p1", "p2"].includes(entry.id) || !Number.isSafeInteger(entry.rqid) || Object.keys(entry).some((key) => !["id", "rqid"].includes(key))) || new Set(expired.map((entry) => entry.id)).size !== expired.length) {
        return result([{ code: "malformed_timeout", field: "expiredSides", message: "Supply one or two expired side requests." }]);
      }
      for (const entry of expired) {
        const side = battle.getSide(entry.id);
        if (!side.requestState || side.isChoiceDone() || side.activeRequest?.rqid !== entry.rqid) {
          return result([{ code: "stale_timeout", field: "rqid", side: side.id, message: "This request is no longer awaiting a choice." }]);
        }
      }
      if (expired.length === 1)
        winner = expired[0].id === "p1" ? "p2" : "p1";
    } else if (request.expiredSides !== void 0) {
      return result([{ code: "malformed_timeout", field: "expiredSides", message: "Match expiry does not use side requests." }]);
    }
    battle.forceWin(winner);
    battle.sendUpdates();
    return result([]);
  });
}
function startStadiumBattle(battles, battleId, requestJson) {
  if (typeof battleId !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(battleId)) {
    return result([{ code: "invalid_battle_id", field: "battleId", message: "Invalid battle ID." }]);
  }
  if (battles.has(battleId))
    return result([{ code: "battle_exists", field: "battleId", message: "Battle ID is already in use." }]);
  let inspected;
  try {
    inspected = inspectRequest(requestJson);
  } catch {
    return result([{ code: "validation_failed", field: "request", message: "Engine validation failed." }]);
  }
  if (!inspected.result.ok || !inspected.request)
    return inspected.result;
  const request = inspected.request;
  const stream = new StadiumBattleStream({ noCatch: true });
  try {
    const format = {
      mod: "cobblemon",
      gameType: request.format.gameType,
      gen: 9,
      // +Past enables move-based Mega Evolution; retain the ordinary Cobblemon rule table.
      ruleset: ["Obtainable", "+Past", "+Unobtainable", ...request.format.teamPreview ? ["Team Preview"] : []],
      effectType: "Format"
    };
    stream._write(`>start ${JSON.stringify({ format })}`);
    if (!stream.battle)
      throw new Error();
    (0, import_stadium_policy.setStadiumPolicy)(stream.battle, {
      teamPreview: request.format.teamPreview ?? false,
      mechanics: request.format.allowedMechanics === void 0 ? void 0 : new Set(request.format.allowedMechanics),
      requestSequence: 0
    });
    for (const side of request.sides)
      stream._write(`>player ${side.id} ${JSON.stringify({ name: side.name ?? side.id, team: side.team })}`);
    if (stream.battle.ended || !stream.battle.started && stream.battle.requestState !== "teampreview")
      throw new Error();
    battles.set(battleId, stream);
    stream.accepted = true;
    stream.onFailure = () => {
      if (battles.get(battleId) === stream)
        battles.delete(battleId);
    };
    return result([]);
  } catch {
    stream._writeEnd();
    return result([{ code: "startup_failed", field: "battle", message: "The engine could not start this battle." }]);
  }
}
//# sourceMappingURL=stadium.js.map
